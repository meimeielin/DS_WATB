package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyMainClass {  // 类名可以随意
    public static void main(String[] args) {
        SpringApplication.run(MyMainClass.class, args);
    }
}
